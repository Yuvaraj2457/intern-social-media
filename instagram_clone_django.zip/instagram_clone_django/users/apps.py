"""User app configuration"""

from django.apps import AppConfig


class UsersConfig(AppConfig):
	"""User app confing"""
    name = 'users'
    verbose_name= 'Users'
